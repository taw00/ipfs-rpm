//+build !windows

package util

func InsideGUI() bool {
	return false
}

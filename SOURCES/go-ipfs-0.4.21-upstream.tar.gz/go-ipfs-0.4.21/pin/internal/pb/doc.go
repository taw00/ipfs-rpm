package pb

//go:generate protoc --gogo_out=. header.proto

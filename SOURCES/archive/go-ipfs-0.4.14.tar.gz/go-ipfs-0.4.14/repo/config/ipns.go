package config

type Ipns struct {
	RepublishPeriod string
	RecordLifetime  string

	ResolveCacheSize int
}

package config

type API struct {
	HTTPHeaders map[string][]string // HTTP headers to return with the API.
}

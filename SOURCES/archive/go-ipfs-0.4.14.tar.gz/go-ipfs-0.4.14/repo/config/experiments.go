package config

type Experiments struct {
	FilestoreEnabled     bool
	ShardingEnabled      bool
	Libp2pStreamMounting bool
}

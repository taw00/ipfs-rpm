---
name: 'Question/Support'
about: 'Ask a question about go-ipfs or request support.'
labels:
  - question
  - invalid
---

This bug tracker is only for actionable bug reports and feature requests. Please direct any questions to https://discuss.ipfs.io or to our Matrix (#ipfs:matrix.org) or IRC (#ipfs on freenode) channels.

If you don't get an immediate response, please keep trying.

// package fuse/readonly implements a fuse filesystem to access files
// stored inside of ipfs.
package readonly

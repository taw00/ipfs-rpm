// +build !linux

package main

func notifyReady() {}

func notifyStopping() {}

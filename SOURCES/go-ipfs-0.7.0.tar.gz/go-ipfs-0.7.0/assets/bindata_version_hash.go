// File generated together with 'bindata.go' when running `go generate .` DO NOT EDIT. (@generated)
package assets

const (
	BindataVersionHash = "514e5ae28d8adb84955801b56ef47aca44bf9cc8"
)

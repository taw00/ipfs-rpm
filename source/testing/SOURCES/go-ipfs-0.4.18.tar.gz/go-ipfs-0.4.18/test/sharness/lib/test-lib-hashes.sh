# this file defines several useful hashes used across the test codebase.
# thus they can be defined + changed in one place

HASH_WELCOME_DOCS="QmS4ustL54uo8FzR9455qaxZwuMiUhyvMcX9Ba8nUH4uVv"
HASH_EMPTY_DIR="QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn"
